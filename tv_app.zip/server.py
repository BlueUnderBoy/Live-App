from tv_app.controllers import controllers_loreg
from tv_app.controllers import controllers_show

from tv_app import app

if __name__ == "__main__":
    app.run(debug=True)